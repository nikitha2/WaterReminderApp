package com.example.android.background.sync;

import android.content.Context;

import com.example.android.background.utilities.NotificationUtils;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class WorkerManagerScheduling extends Worker {
    public WorkerManagerScheduling(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        NotificationUtils.remindUserBecauseCharging(getApplicationContext());
        return Result.success();
    }
}
